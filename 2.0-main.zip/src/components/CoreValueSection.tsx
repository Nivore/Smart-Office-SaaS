import { Globe, ShieldCheck, Zap, LayoutDashboard, Cpu, BarChart3 } from "lucide-react";

const coreValues = [
  {
    icon: <Cpu className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-blue-400" />,
    title: "통합 에코시스템 구축",
    subTitle: "All-in-One",
    description: "하드웨어와 소프트웨어를 단일 브랜드로 결합하여 관리 효율을 극대화합니다.",
  },
  {
    icon: <LayoutDashboard className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-purple-400" />,
    title: "고시인성 직관 UI",
    subTitle: "Smart Design",
    description: "LED 월패드 기반의 인터페이스로 별도 교육 없이 누구나 즉시 사용 가능합니다.",
  },
  {
    icon: <Zap className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-yellow-400" />,
    title: "지능형 에너지 제어",
    subTitle: "Cost Saving",
    description: "IoT 연동을 통해 미사용 공간의 전력을 자동 차단, 운영 비용을 실질적으로 절감합니다.",
  },
  {
    icon: <BarChart3 className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-emerald-400" />,
    title: "자율 운영 최적화",
    subTitle: "Efficiency",
    description: "노쇼 자동 취소 및 원터치 연장으로 회의실 가동률을 30% 이상 향상시킵니다.",
  },
  {
    icon: <Globe className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-cyan-400" />,
    title: "글로벌 인프라 대응",
    subTitle: "Global Standard",
    description: "다국어 지원 및 클라우드 환경 최적화로 글로벌 통합 관리가 가능합니다.",
  },
  {
    icon: <ShieldCheck className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-blue-500" />,
    title: "검증된 보안 및 신뢰성",
    subTitle: "Reliability",
    description: "GS인증 1등급 획득 및 Azure 기반의 엔터프라이즈급 보안을 보장합니다.",
  },
];

const WhyChooseUs = () => {
  return (
    <section id="coreValue" className="py-16 sm:py-20 lg:py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="text-center mb-16 sm:mb-20 lg:mb-24">
          <span className="inline-block px-4 sm:px-5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm sm:text-base lg:text-lg font-semibold mb-4 sm:mb-6">
            차별화 기술
          </span>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mb-4 sm:mb-6 px-4">
            왜 <span className="text-blue-500">동아피엠<br className="sm:hidden" /></span> 스마트 회의실 플랫폼인가?
          </h2>
        </div>

         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {coreValues.map((value, idx) => (
            <div 
              key={idx} 
              className="p-6 sm:p-7 lg:p-8 rounded-2xl sm:rounded-[1.75rem] lg:rounded-[2rem] bg-white/5 border border-white/10 hover:border-blue-500/50 transition-all duration-300 group"
            >
              <div className="mb-4 sm:mb-5 lg:mb-6 inline-block p-3 sm:p-3.5 lg:p-4 rounded-xl sm:rounded-2xl bg-white/5 group-hover:scale-110 transition-transform">
                {value.icon}
              </div>
              <div className="mb-3 sm:mb-4">
                <span className="text-xs font-semibold text-blue-400 uppercase tracking-widest">
                  {value.subTitle}
                </span>
                <h4 className="text-xl sm:text-xl lg:text-2xl font-semibold text-foreground mt-1">{value.title}</h4>
              </div>
              <p className="text-slate-400 text-sm sm:text-base lg:text-lg leading-relaxed font-medium">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;