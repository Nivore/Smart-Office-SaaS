import { CalendarCheck, TimerOff, History, CheckCircle2 } from "lucide-react";
import smartWallpadImg from "./assets/meeting_en.png";

const features = [
  {
    icon: CalendarCheck,
    titleKo: "간편 즉시 예약",
    titleEn: "Easy Booking",
    description: "웹과 모바일에서 빈 회의실을 실시간 확인하고 클릭 한 번으로 예약합니다.",
    gradient: "from-blue-500/20 to-cyan-500/20",
    badge: "평균 3초 완료",
    iconColor: "text-blue-400",
  },
  {
    icon: TimerOff,
    titleKo: "노쇼 자동 취소",
    titleEn: "No-Show Zero",
    description: "미체크인 시 예약이 자동 취소되어 공간 낭비를 실시간으로 차단합니다.",
    gradient: "from-purple-500/20 to-pink-500/20",
    badge: "가동률 최적화",
    iconColor: "text-purple-400",
  },
  {
    icon: History,
    titleKo: "끊김 없는 연장",
    titleEn: "Smart Extension",
    description: "월패드 터치 한 번으로 뒷시간을 확인하고 즉시 회의를 연장할 수 있습니다.",
    gradient: "from-emerald-500/20 to-teal-500/20",
    badge: "1터치 연장",
    iconColor: "text-emerald-400",
  },
];

const FeatureCards = () => {
  return (
    <section id="features" className="py-16 sm:py-20 lg:py-24 relative overflow-hidden bg-secondary/30 text-foreground">
      {/* 배경 글로우 효과 */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-1/4 w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] bg-blue-600/10 rounded-full blur-[100px] sm:blur-[120px]" />
        <div className="absolute bottom-0 left-1/4 w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] bg-purple-600/10 rounded-full blur-[100px] sm:blur-[120px]" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 relative z-10">
        
        {/* 헤더 */}
        <div className="text-center mb-16 sm:mb-20 lg:mb-24">
          <span className="inline-block px-4 sm:px-5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm sm:text-base lg:text-lg font-semibold mb-4 sm:mb-6">
            핵심 기능 안내
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-semibold tracking-tight mb-6 sm:mb-8 px-4">
            임직원은 더 쉽게,
            <br />
            <span className="text-transparent bg-clip-text font-semibold bg-gradient-to-r from-blue-400 to-purple-400">
              관리는 더 똑똑하게
            </span>
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto leading-relaxed text-base sm:text-lg lg:text-xl font-medium px-4">
            클릭 한 번으로 끝나는 예약부터 자동 관리까지. <br className="hidden sm:block" />
            GS인증 1등급 기술력으로 운영 고민을 해결합니다.
          </p>
        </div>

        {/* 상단 3개 카드 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-24 sm:mb-32 lg:mb-40">
          {features.map((feature, index) => (
            <div key={index} className="group relative bg-white/5 border-2 border-white/10 rounded-2xl sm:rounded-[2rem] lg:rounded-[2.5rem] p-6 sm:p-8 lg:p-10 hover:bg-black/10 hover:border-white/20 transition-all duration-300">
              <div className="flex items-start justify-between mb-6 sm:mb-8">
                <div className={`w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-xl sm:rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center`}>
                  <feature.icon className={`w-6 h-6 sm:w-7 sm:h-7 lg:w-9 lg:h-9 ${feature.iconColor}`} />
                </div>
                {/* 배지 */}
                <div className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg sm:rounded-xl bg-black/10 border border-white/20 backdrop-blur-md">
                  <span className={`text-xs sm:text-sm lg:text-base font-semibold uppercase tracking-tight ${feature.iconColor}`}>
                    {feature.badge}
                  </span>
                </div>
              </div>

              <h3 className="text-lg sm:text-xl lg:text-2xl font-semibold mb-3 sm:mb-4 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                <span>{feature.titleKo}</span>
                <span className="text-xs sm:text-sm font-semibold text-slate-500 uppercase tracking-widest">
                  {feature.titleEn}
                </span>
              </h3>
              <p className="text-slate-400 leading-relaxed text-sm sm:text-base lg:text-lg font-medium">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* 하단 상세 섹션 */}
        <div className="flex flex-col-reverse md:flex-row items-start md:items-center gap-12 sm:gap-16 lg:gap-24">
          <div className="flex-1 order-2 lg:order-1 w-full">
            <div className="mb-8 sm:mb-12">
              <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs sm:text-sm font-semibold mb-4 sm:mb-6">
                SMART DEVICE SYNC
              </div>
              <h3 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-semibold mb-6 sm:mb-8 leading-[1.2] tracking-tight ml-0 sm:ml-2">
                현장과 시스템의 완벽한 일치,<br />
                회의실 혼선을 <span className="text-purple-400">원천 차단</span>합니다.
              </h3>
              <p className="text-slate-300 text-base sm:text-lg lg:text-xl leading-relaxed font-medium ml-0 sm:ml-2">
                스마트 월패드와 서버가 실시간으로 통신하여 <br className="hidden sm:block" />
                현장 예약 정보를 즉시 반영하고 투명하게 공개합니다.
              </p>
            </div>

            <div className="space-y-6 sm:space-y-8">
              {[
                { title: "실시간 현황 대시보드", desc: "월패드 실시간 현황 표출로 중복 예약 및 혼선을 원천 차단합니다." },
                { title: "현장 즉시 예약(Walk-in)", desc: "시스템 접속의 번거로움 없이 현장에서 즉시 예약하고 바로 업무에 몰입하세요." },
                { title: "운영 투명성 확보", desc: "현장 스케줄의 대외 공개로 무단 점유를 방지하고 조직 내 신뢰를 높입니다." }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4 sm:gap-6 items-start group">
                  <div className="mt-1 ml-0 sm:ml-2 bg-blue-500/20 p-1.5 sm:p-2 rounded-lg group-hover:bg-blue-500/40 transition-colors flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-purple-400" />
                  </div>
                  <div>
                    <h4 className="text-lg sm:text-xl lg:text-2xl font-normal text-foreground mb-1 sm:mb-2">{item.title}</h4>
                    <p className="text-sm sm:text-base lg:text-lg text-slate-400 font-medium leading-snug">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 우측 이미지 */}
          <div className="flex-1 order-1 lg:order-2 w-full relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-blue-500/20 to-purple-500/20 blur-2xl rounded-[2rem] sm:rounded-[3rem]" />
            <div className="relative transform hover:scale-105 transition-transform duration-700">
              <div className="rounded-lg sm:rounded-xl lg:rounded-[0.8rem] border border-black/20 shadow-xl sm:shadow-2xl overflow-hidden bg-slate-900">
                <img 
                  src={smartWallpadImg} 
                  className="w-full h-auto object-contain min-h-[250px] sm:min-h-[350px] lg:min-h-[400px]" 
                  alt="스마트 월패드 화면 예시" 
                />
              </div>
              {/* 라이브 배지 */}
              <div className="absolute -bottom-4 sm:-bottom-6 -right-4 sm:-right-6 bg-slate-900 border border-white/20 p-3 sm:p-4 rounded-xl sm:rounded-2xl flex items-center gap-2 sm:gap-4 shadow-2xl backdrop-blur-xl">
                <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]" />
                <span className="text-xs sm:text-sm font-normal text-foreground tracking-widest uppercase">Live Sync</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default FeatureCards;