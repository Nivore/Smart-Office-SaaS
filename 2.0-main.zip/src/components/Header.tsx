import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Globe, Menu, X } from "lucide-react";
import logoSvg from "./assets/logo.svg";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDarkMode);
  }, [isDarkMode]);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const navLinks = [
    { label: "스마트 월패드", href: "#hero" },
    { label: "기능소개", href: "#features" },
    { label: "핵심가치", href: "#trust" },
    { label: "문의하기", href: "#contact" },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-card">
      <div className="container mx-auto section-px py-3 sm:py-4">
        <nav className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <img 
              src={logoSvg} 
              alt="Logo" 
              className="w-24 sm:w-32 h-5 sm:h-6 brightness-0 invert"
            />
            <span className="hidden sm:inline text-white/50 font-regular tracking-tight body-sm">
              | Workspace OS
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-4">
            {navLinks.map((link) => (
              <a 
                key={link.href} 
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="nav-link text-base lg:text-lg"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA Buttons - Desktop */}
          <div className="hidden md:flex items-center gap-2">
            <Button 
              variant="ghost"
              className="flex items-center gap-1.5 px-3 py-2 body-sm text-text-secondary hover:text-text-primary transition-colors rounded-lg hover:bg-muted"
            >
              <Globe className="w-4 h-4" />
              <span>KR</span>
            </Button>
            <Button variant="ghost" size="sm" className="text-white hover:text-foreground hover:bg-muted">
              로그인
            </Button>
            <Button size="sm" className="bg-primary hover:bg-primary/90 glow-primary text-sm sm:text-base font-medium">
              무료 체험하기
            </Button>
          </div>

          {/* Mobile CTA + Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <Button 
              size="sm" 
              className="bg-primary hover:bg-primary/90 text-xs sm:text-sm font-medium px-3 sm:px-4"
            >
              무료 체험
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-white hover:bg-muted p-2"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </nav>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden mobile-menu-overlay top-[60px]">
          <div className="container mx-auto section-px py-8">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="mobile-nav-link"
                >
                  {link.label}
                </a>
              ))}
              <div className="h-px bg-white/10 my-4" />
              <Button variant="ghost" size="lg" className="justify-start text-white hover:bg-white/10">
                로그인
              </Button>
              <Button 
                variant="ghost"
                className="justify-start flex items-center gap-2 text-white/70 hover:text-white hover:bg-white/10"
              >
                <Globe className="w-4 h-4" />
                <span>한국어 (KR)</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;