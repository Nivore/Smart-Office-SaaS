const footerLinks = {
  솔루션: ["좌석 예약", "회의실 관리", "방문자 관리", "공간 분석"],
  고객지원: ["헬프센터", "API 문서", "시스템 상태", "문의하기"],
};

const Footer = () => {
  return (
    <footer className="bg-secondary/30 text-foreground">
      <div className="container mx-auto py-12 sm:py-16 lg:py-20 px-4 sm:px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-8 lg:gap-12">
          <div className="sm:col-span-2 lg:col-span-4">
            <img 
              src="/src/components/assets/logo.svg" 
              alt="Dongapm Logo" 
              className="h-7 sm:h-8 w-auto mb-1 brightness-0 invert" 
            />
            <span className="text-foreground/50 font-regular tracking-tight text-sm sm:text-base">
              Smart Office
            </span>
            
            {/* 대한민국 스마트오피스의 기준 */}
            <p className="text-base sm:text-lg font-bold text-foreground mt-4 sm:mt-6 mb-1">대한민국 스마트오피스의 기준</p>
            <p className="text-xs sm:text-sm text-foreground/60 max-w-xs mb-4 sm:mb-6">
              공공기관과 글로벌 기업이 신뢰하는 <br />
              No.1 스마트 오피스 솔루션
            </p>

            {/* GS인증 1등급 배지 */}
            <div className="flex gap-2">
              <span className="px-2 py-1 bg-white/5 border border-white/10 rounded text-xs sm:text-[13px] font-medium text-foreground/80">
                GS인증 1등급
              </span>
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="col-span-1">
              <h4 className="text-sm sm:text-base font-semibold text-foreground mb-3 sm:mb-4">{category}</h4>
              <ul className="space-y-2 sm:space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-xs sm:text-sm text-foreground/60 hover:text-foreground transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 하단 바: 기업 상세 정보 추가 */}
         <div className="mt-12 sm:mt-16 pt-6 sm:pt-8 border-t border-white/10">
          <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between gap-4 sm:gap-6">
            <div className="space-y-1.5 sm:space-y-2 text-xs sm:text-sm text-foreground/50">
              {/* 대표 및 사업자 정보 */}
              <div className="flex flex-wrap gap-x-3 sm:gap-x-4">
                <p>대표: 박병후</p>
                <p>사업자등록번호: 000-00-00000</p>
              </div>
              {/* 주소 및 전화번호 */}
              <p className="leading-relaxed">
                서울특별시 마포구 큰우물로 75 
                <span className="mx-1 text-foreground/20 hidden sm:inline">|</span>
                <br className="sm:hidden" /> 
                대표전화 02-701-3360
              </p>
              <p className="text-[10px] sm:text-xs pt-1 sm:pt-2 text-foreground/30">
                ©2026 (주)동아피엠. All rights reserved.
              </p>
            </div>

            <div className="flex items-center gap-4 sm:gap-6">
              <a href="#" className="text-xs sm:text-sm text-foreground/60 hover:text-foreground transition-colors">
                이용약관
              </a>
              <a href="#" className="text-xs sm:text-sm text-foreground/60 hover:text-foreground transition-colors font-semibold">
                개인정보처리방침
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;