import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight, Calendar, Users, Settings } from "lucide-react";

interface Particle {
  id: number;
  left: number;
  size: number;
  color: string;
  duration: number;
  delay: number;
  drift: number;
  bottom: number;
}

const HeroSection = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [particles, setParticles] = useState<Particle[]>([]);
  const particleIdRef = useRef(0);

  // 초기 입자 생성
  useEffect(() => {
    const initialParticles: Particle[] = [];
    const colors = [
      'rgba(139, 92, 246, 0.6)',   // primary/purple
      'rgba(99, 102, 241, 0.5)',   // indigo
      'rgba(168, 85, 247, 0.7)',   // violet
      'rgba(147, 51, 234, 0.4)',   // purple-light
      'rgba(255, 255, 255, 0.3)',  // white
    ];

    for (let i = 0; i < 80; i++) {
      initialParticles.push({
        id: particleIdRef.current++,
        left: Math.random() * 100,
        size: Math.random() * 4 + 2,
        color: colors[Math.floor(Math.random() * colors.length)],
        duration: Math.random() * 10 + 10,
        delay: 0,
        drift: (Math.random() - 0.5) * 100,
        bottom: Math.random() * 120,
      });
    }

    setParticles(initialParticles);
  }, []);

  // 주기적으로 새 입자 추가
  useEffect(() => {
    const colors = [
      'rgba(139, 92, 246, 0.6)',
      'rgba(99, 102, 241, 0.5)',
      'rgba(168, 85, 247, 0.7)',
      'rgba(147, 51, 234, 0.4)',
      'rgba(255, 255, 255, 0.3)',
    ];

    const interval = setInterval(() => {
      setParticles((prev) => {
        // 최대 입자 수 제한만 체크, 기존 입자는 유지
        if (prev.length < 100) {
          const newParticle: Particle = {
            id: particleIdRef.current++,
            left: Math.random() * 100,
            size: Math.random() * 4 + 2,
            color: colors[Math.floor(Math.random() * colors.length)],
            duration: Math.random() * 10 + 10,
            delay: 0,
            drift: (Math.random() - 0.5) * 100,
            bottom: -5,
          };
          return [...prev, newParticle];
        }
        return prev;
      });
    }, 3000); // 3초마다 새 입자 추가

    return () => clearInterval(interval);
  }, []);

  // 입자 제거는 하지 않음 - infinite 애니메이션이므로 계속 반복됨

  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [isDarkMode]);

  return (
    <section id="hero" className="relative section-py pt-24 sm:pt-32 lg:pt-36 pb-32 sm:pb-48 lg:pb-60 overflow-hidden bg-[#0a0a0a]">
      
      {/* 배경 글로우 효과 */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* 하단 그라데이션 글로우 */}
        <div className="absolute -bottom-1/2 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary/20 rounded-full blur-[150px]" />
        
        {/* 상단 어두운 그라데이션 */}
        <div className="absolute -top-1/2 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-primary/10 rounded-full blur-[120px]" />
      </div>

      {/* 떠오르는 입자들 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute rounded-full animate-float-up"
            style={{
              left: `${particle.left}%`,
              bottom: `${particle.bottom}vh`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              backgroundColor: particle.color,
              boxShadow: `0 0 ${particle.size * 2}px ${particle.color}`,
              animationDuration: `${particle.duration}s`,
              animationDelay: `${particle.delay}s`,
              '--float-x': `${particle.drift}px`,
            } as React.CSSProperties}
          />
        ))}
      </div>

      <div className="section-container relative z-10">
        {/* 헤더 텍스트 영역 */}
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto space-responsive-md">
          <div className="mb-2 animate-fade-in">
            <img 
              src="/src/components/assets/worko-brand_dark.svg"
              alt="work:o bi logo" 
              className="h-6 sm:h-7 md:h-8 w-auto object-contain"
            />
          </div>
          <h1 className="heading-xl px-4">
            회의실 운영의 모든 것,<br />
            <span className="gradient-text">단 하나의 플랫폼으로.</span>
          </h1>
          <p className="text-slate-400 max-w-xl mx-auto leading-relaxed body-lg mb-4 sm:mb-6 px-4">
            예약 소프트웨어부터 월패드, IoT 환경 제어까지 빈틈없이 연결합니다. GS인증 1등급 기술력으로 검증된 올인원 솔루션을 경험하세요.
          </p>
          <div className="flex flex-col sm:flex-row gap-responsive-sm w-full sm:w-auto px-4">
            <Button size="lg" className="bg-primary glow-primary body-lg w-full sm:w-auto">
              무료 체험하기
            </Button>
            <Button variant="ghost" size="lg" className="text-slate-300 dark:text-gray-200 body-lg hover:bg-muted w-full sm:w-auto">
              제품 알아보기 <ChevronRight className="ml-1 w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* 3D 스테이지 - 반응형 */}
        <div className="perspective-container relative mt-12 sm:mt-16 lg:mt-0 h-[300px] sm:h-[450px] lg:h-[700px] w-full">
          
          {/* Base Layer (메인 대시보드 이미지) */}
          <div 
            className="absolute left-1/2 top-0 origin-center rounded-[8px] sm:rounded-[12px] shadow-[0_30px_60px_rgba(0,0,0,0.4)] sm:shadow-[0_50px_100px_rgba(0,0,0,0.5)]"
            style={{
              width: "95%",
              maxWidth: "1200px",
              height: "auto",
              aspectRatio: "16/10",
              transform: `
                translateX(-50%) 
                rotateX(47deg) 
                rotateY(10deg) 
                rotate(-15deg)
              `,
              transformStyle: "preserve-3d",
            }}
          >
            <img 
              src="/src/components/assets/meeting_en.png" 
              alt="Dashboard"
              className="w-full h-full object-contain opacity-80 rounded-[8px] sm:rounded-[12px]"
            />

            {/* Floating Elements */}
            
            {/* 왼쪽 상단 아이콘 박스 */}
            <div 
              className="float-box-sm top-20 lg:top-20 left-6 lg:left-14"
              style={{ transform: "translateZ(40px) sm:translateZ(60px) lg:translateZ(80px)" }}
            >
              <div className="hidden lg:flex gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <div className="w-2 h-2 rounded-full bg-yellow-500" />
                <div className="w-2 h-2 rounded-full bg-green-500" />
              </div>
              <Calendar className="w-5 h-5 sm:w-6 sm:h-6 lg:w-8 lg:h-8 text-primary ml-0 lg:ml-1" />
            </div>

            {/* 오른쪽 중간 유저 정보 박스 */}
            <div 
              className="float-box-md top-1/3 sm:top-2/4 lg:top-60 right-16 lg:right-20"
              style={{ transform: "translateZ(60px) sm:translateZ(90px) lg:translateZ(120px)" }}
            >
              <div className="flex items-center gap-2 lg:gap-3">
                <div className="w-7 h-7 sm:w-8 sm:h-8 lg:w-10 lg:h-10 rounded-full bg-gradient-to-tr from-primary to-blue-500" />
                <div className="text-left">
                  <p className="text-responsive-xs text-muted-foreground font-medium">현재 예약 중</p>
                  <p className="text-responsive-sm font-bold text-white">대회의실 A</p>
                </div>
              </div>
            </div>

            {/* 하단 제어 위젯 */}
            <div 
              className="hidden lg:block absolute bottom-20 left-1/3 p-4 px-8 rounded-full card-glass border border-white/20 shadow-2xl animate-float-3d"
              style={{ transform: "translateZ(150px)" }}
            >
              <div className="flex items-center gap-6">
                <Settings className="w-5 h-5 text-white/50" />
                <div className="h-4 w-px bg-white/10" />
                <Users className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium text-white">12명 참석 가능</span>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;