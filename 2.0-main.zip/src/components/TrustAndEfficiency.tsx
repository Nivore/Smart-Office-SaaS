import { Timer , FileSpreadsheet, Users2 } from "lucide-react";

const TrustAndEfficiency = () => {
  return (
    <section id="trust" className="py-16 sm:py-20 lg:py-24 bg-secondary/30 text-foreground overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6">
        
        {/* 상단: 검증된 기술력 섹션 */}
        <div className="text-center mb-16 sm:mb-20">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-semibold mb-12 sm:mb-14 lg:mb-16 tracking-tight px-4">
            <span className="text-sky-500">엔터프라이즈급 안정성</span>을 <br className="hidden sm:block" />보장하는 기술 인프라
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
            {/* GS인증 */}
            <div className="flex flex-col items-center px-4">
              <div className="mb-4 sm:mb-5 lg:mb-6 h-16 sm:h-18 lg:h-20 flex items-center justify-center">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 sm:w-18 sm:h-18 lg:w-20 lg:h-20 rounded-full border-4 border-sky-500 flex items-center justify-center relative">
                    <span className="text-2xl sm:text-3xl font-bold text-sky-500">GS</span>
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 bg-sky-500 rounded-full flex items-center justify-center">
                      <svg className="w-3 h-3 sm:w-4 sm:h-4 text-foreground" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                      </svg>
                    </div>
                  </div>
                  <span className="text-xs sm:text-sm text-muted-foreground mt-2">Good Software</span>
                </div>
              </div>
              <h4 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3">GS인증 1등급 획득</h4>
              <p className="text-slate-400 text-sm leading-relaxed max-w-[280px]">
                공공 및 금융권 도입이 검증된 소프트웨어 품질
              </p>
            </div>

            {/* MS Azure */}
            <div className="flex flex-col items-center px-4">
              <div className="mb-4 sm:mb-5 lg:mb-6 h-16 sm:h-18 lg:h-20 flex items-center justify-center gap-2">
                <div className="flex items-center gap-2">
                  <svg className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M33.338 6.544h26.038l-27.03 80.087a4.152 4.152 0 01-3.933 2.824H8.149a4.145 4.145 0 01-3.928-5.47L29.404 9.369a4.152 4.152 0 013.934-2.825z" fill="url(#azure-a)"></path>
                    <path d="M71.175 60.261H41.387a1.911 1.911 0 00-1.305 3.309l26.532 24.764a4.171 4.171 0 002.846 1.121h23.618L71.175 60.261z" fill="#0078D4"></path>
                    <path d="M33.338 6.544a4.118 4.118 0 00-3.943 2.879L4.252 83.917a4.14 4.14 0 003.908 5.538h20.787a4.443 4.443 0 003.529-2.879l5.297-15.642 18.62 17.387a4.233 4.233 0 002.669 1.134h23.497l-10.101-29.194-32.665-.001 24.263-47.716H33.338z" fill="url(#azure-b)"></path>
                    <path d="M66.595 9.364a4.145 4.145 0 00-3.928-2.82H33.648a4.146 4.146 0 013.928 2.82l25.184 74.62a4.146 4.146 0 01-3.928 5.471h29.02a4.146 4.146 0 003.927-5.47L66.595 9.363z" fill="url(#azure-c)"></path>
                    <defs>
                      <linearGradient id="azure-a" x1="46.153" y1="10.117" x2="16.17" y2="93.028" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#114A8B"></stop>
                        <stop offset="1" stopColor="#0669BC"></stop>
                      </linearGradient>
                      <linearGradient id="azure-b" x1="56.293" y1="46.031" x2="48.039" y2="48.673" gradientUnits="userSpaceOnUse">
                        <stop stopOpacity=".3"></stop>
                        <stop offset=".071" stopOpacity=".2"></stop>
                        <stop offset=".321" stopOpacity=".1"></stop>
                        <stop offset=".623" stopOpacity=".05"></stop>
                        <stop offset="1" stopOpacity="0"></stop>
                      </linearGradient>
                      <linearGradient id="azure-c" x1="50.122" y1="8.217" x2="80.104" y2="91.128" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#3CCBF4"></stop>
                        <stop offset="1" stopColor="#2892DF"></stop>
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="flex flex-col items-start">
                    <span className="text-sm sm:text-base ml-1 text-muted-foreground">Microsoft</span>
                    <span className="text-2xl sm:text-3xl font-semibold text-sky-500">Azure</span>
                  </div>
                </div>
              </div>
              <h4 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3">MS Azure Cloud</h4>
              <p className="text-slate-400 text-sm leading-relaxed max-w-[280px]">
                글로벌 수준의 보안 체계와 99.9% 무중단 서비스
              </p>
            </div>

            {/* 보안 프로토콜 */}
           <div className="flex flex-col items-center px-4">
              <div className="w-16 h-16 sm:w-18 sm:h-18 lg:w-20 lg:h-20 mb-4 sm:mb-5 lg:mb-6 flex items-center justify-center bg-slate-800 rounded-xl sm:rounded-2xl shadow-xl border border-white/10">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shield-check w-10 h-10 sm:w-11 sm:h-11 lg:w-12 lg:h-12 text-blue-400">
                  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path>
                  <path d="m9 12 2 2 4-4"></path>
                </svg>
              </div>
              <h4 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3">보안 프로토콜</h4>
              <p className="text-slate-400 text-sm leading-relaxed max-w-[280px]">
                철저한 데이터 암호화 및 무결성 보안 관리
              </p>
            </div>
          </div>
        </div>

        {/* 하단: 관리 효율성 섹션 */}
         <div className="mt-20 sm:mt-28 lg:mt-32">
          <div className="text-center mb-8 sm:mb-10 lg:mb-12">
            <h3 className="text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight px-4">
              IT 전문가 없이도 누구나 가능한 <br className="hidden sm:block" />
              <span className="text-emerald-400">자율형 운영 시스템</span>
            </h3>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl sm:rounded-3xl lg:rounded-[2.5rem] p-6 sm:p-10 lg:p-16">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-10 lg:gap-12">
              {/* 비용 및 세팅 */}
              <div className="text-center">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-yellow-500/20 border border-yellow-500/30 rounded-xl sm:rounded-2xl mx-auto flex items-center justify-center">
                  <Timer className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-yellow-500" />
                </div>
                <p className="text-base sm:text-lg text-yellow-500 mt-3 sm:mt-4">경제적인 도입 비용</p>
                <h4 className="text-xl sm:text-2xl font-bold my-3 sm:my-4">초기 비용 0원, 1분이면 준비 끝!</h4>
                <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
                  설치가 필요 없어 초기 비용이 발생하지 않습니다. 기존 엑셀 파일 업로드만으로 즉시 회의실 예약을 시작하세요.
                </p>
              </div>

              {/* 데이터 연동 */}
              <div className="text-center">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-green-500/20 border border-green-500/30 rounded-xl sm:rounded-2xl mx-auto flex items-center justify-center">
                  <FileSpreadsheet className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-green-500" />
                </div>
                <p className="text-base sm:text-lg text-emerald-400 mt-3 sm:mt-4">스마트 데이터 매핑</p>
                <h4 className="text-xl sm:text-2xl font-semibold my-3 sm:my-4">엑셀 업로드만으로 완성되는 조직도</h4>
                <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
                  복잡한 API 개발 없이 사용 당시 엑셀 파일들을 끌어다 놓기만 하면 조직도와 사용자 계정이 자동으로 생성됩니다.
                </p>
              </div>
              
              {/* 인사 이동 관리 */}
              <div className="text-center">
                <div className="w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-blue-500/20 border border-blue-500/30 rounded-xl sm:rounded-2xl mx-auto flex items-center justify-center">
                  <Users2 className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-blue-500" />
                </div>
                <p className="text-base sm:text-lg text-blue-400 mt-3 sm:mt-4">현업 중심의 자율 관리</p>
                <h4 className="text-xl sm:text-2xl font-semibold my-3 sm:my-4">IT 의존 없는 권한 통합 제어</h4>
                <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
                  부서별/직급별 예약 인원 설정을 탭셀 배열로 일괄 처리하여 IT 전문 인력 없이도 현업 부서에서 직접 관리합니다.
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default TrustAndEfficiency;