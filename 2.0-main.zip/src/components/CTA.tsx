import { Button } from "@/components/ui/button";
import { ArrowRight, Check } from "lucide-react";

const benefits = [
  "한 달간 무료 체험",
  "도입 비용 부담 Zero",
  "전담 기술지원팀 상주",
  "유연한 시스템 최적화",
];

const CTA = () => {
  return (
    <section id="contact" className="py-16 sm:py-20 lg:py-24 relative overflow-hidden">
      <div className="container relative mx-auto px-4 sm:px-6">
        <div className="relative rounded-2xl sm:rounded-3xl glass-panel p-8 sm:p-12 lg:p-16 overflow-hidden bg-secondary/30">
          {/* Background Effects */}
          <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-primary/10 to-transparent" />
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/20 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-accent/20 rounded-full blur-3xl" />

          <div className="relative grid lg:grid-cols-2 gap-8 sm:gap-10 lg:gap-12 items-center">
            {/* Left Content */}
           <div className="space-y-4 sm:space-y-6">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold">
                오늘부터 바꾸는{" "}
                <span className="gradient-text">스마트 오피스</span>
                <br />
                회의실 관리의 기준이 됩니다.
              </h2>
              <p className="text-muted-foreground text-sm sm:text-base max-w-md">
                번거로운 예약 관리는 시스템에 맡기고, 본연의 업무에만 집중하세요. <br className="hidden sm:block" />
                전문가가 귀사 환경에 최적화된 운영 모델을 제안합니다. 
              </p>
              
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-purple-400 flex-shrink-0" />
                    <span className="text-foreground/80">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right Content - Form */}
            <div className="glass-panel rounded-xl sm:rounded-2xl p-5 sm:p-6 lg:p-8 space-y-4 sm:space-y-6">
              <div className="space-y-3 sm:space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <input
                    type="text"
                    placeholder="이름"
                    className="w-full px-4 py-2.5 sm:py-3 text-sm sm:text-base rounded-lg bg-background/50 border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                  />
                  <input
                    type="text"
                    placeholder="회사명"
                    className="w-full px-4 py-2.5 sm:py-3 text-sm sm:text-base rounded-lg bg-background/50 border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                  />
                </div>
                <input
                  type="email"
                  placeholder="이메일"
                  className="w-full px-4 py-2.5 sm:py-3 text-sm sm:text-base rounded-lg bg-background/50 border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                />
                <input
                  type="tel"
                  placeholder="연락처"
                  className="w-full px-4 py-2.5 sm:py-3 text-sm sm:text-base rounded-lg bg-background/50 border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-all"
                />
              </div>
              <Button variant="default" className="w-full bg-primary shadow-[0_0_20px_rgba(0,0,0,0.2)] text-base sm:text-lg" size="lg">
                무료상담 신청하기
              </Button>
              <p className="text-xs sm:text-sm text-center text-muted-foreground">
                제출 시 <a href="#" className="text-blue-400 hover:underline">개인정보 처리방침</a>에 동의하게 됩니다.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;