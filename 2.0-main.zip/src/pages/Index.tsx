import { useState, useEffect } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import FeatureCards from "@/components/FeatureCards";
import CTA from "@/components/CTA";
import CoreValueSection from "@/components/CoreValueSection";
import TrustAndEfficiency from "@/components/TrustAndEfficiency";
import Footer from "@/components/Footer";

const Index = () => {
  // 1. 모든 섹션이 공유할 다크모드 상태를 여기서 관리 (기본값 다크모드: true)
  const [isDarkMode, setIsDarkMode] = useState(true);

  // 2. 상태가 바뀔 때마다 <html> 태그에 .dark 클래스를 넣었다 뺐다 함
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      {/* 3. Header에는 상태를 바꿀 수 있는 함수(setIsDarkMode)까지 전달 */}
      <Header isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} />
      
      <main>
        {/* 4. HeroSection에는 현재 상태(isDarkMode)만 전달해서 로고 분기에 사용 */}
        <HeroSection isDarkMode={isDarkMode} />
        
        {/* 필요한 경우 다른 섹션에도 isDarkMode를 전달할 수 있습니다 */}
        <FeatureCards isDarkMode={isDarkMode} />
        <CoreValueSection isDarkMode={isDarkMode} />
        <TrustAndEfficiency isDarkMode={isDarkMode} />
        <CTA isDarkMode={isDarkMode} />
      </main>
      
      <Footer isDarkMode={isDarkMode} />
    </div>
  );
};

export default Index;