import type { Config } from "tailwindcss";
import plugin from "tailwindcss/plugin";
import tailwindcssAnimate from "tailwindcss-animate";

export default {
  darkMode: ["class"],
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      fontFamily: {
        sans: ['"Pretendard Variable"', 'Pretendard', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'Roboto', 'sans-serif'],
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      lineHeight: {
        relaxed: "1.6",
      },
      letterSpacing: {
        tight: "-0.02em",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "float": {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        },
        "glow-pulse": {
          "0%, 100%": { opacity: "0.6" },
          "50%": { opacity: "1" },
        },
        "float-3d": {
          "0%, 100%": { transform: "translateZ(80px) translateY(0px)" },
          "50%": { transform: "translateZ(100px) translateY(-20px)" },
        },
        "float-3d-delayed": {
          "0%, 100%": { transform: "translateZ(120px) translateY(0px)" },
          "50%": { transform: "translateZ(140px) translateY(-30px)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "float": "float 6s ease-in-out infinite",
        "glow-pulse": "glow-pulse 3s ease-in-out infinite",
        "float-3d": "float-3d 6s ease-in-out infinite",
        "float-3d-delayed": "float-3d-delayed 8s ease-in-out infinite",
      },
    },
  },
  plugins: [
    tailwindcssAnimate,
    // Custom utility plugin for common patterns
    plugin(function({ addComponents }) {
      addComponents({
        // Section styles
        '.section-py': {
          '@apply py-16 sm:py-20 lg:py-24': {},
        },
        '.section-px': {
          '@apply px-4 sm:px-6': {},
        },
        
        // Heading styles
        '.heading-xl': {
          '@apply text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-semibold tracking-tight': {},
        },
        '.heading-lg': {
          '@apply text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-semibold tracking-tight': {},
        },
        '.heading-md': {
          '@apply text-xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold tracking-tight': {},
        },
        '.heading-sm': {
          '@apply text-lg sm:text-xl lg:text-2xl font-semibold': {},
        },
        
        // Body text
        '.body-lg': {
          '@apply text-base sm:text-lg lg:text-xl': {},
        },
        '.body-md': {
          '@apply text-sm sm:text-base lg:text-lg': {},
        },
        '.body-sm': {
          '@apply text-xs sm:text-sm': {},
        },
        
        // Card styles
        '.card-base': {
          '@apply rounded-2xl sm:rounded-[1.75rem] lg:rounded-[2rem] bg-white/5 border border-white/10': {},
        },
        '.card-hover': {
          '@apply hover:border-blue-500/50 transition-all duration-300': {},
        },
        '.card-glass': {
          '@apply backdrop-blur-xl bg-white/5 border border-white/10': {},
        },
        
        // Icon container
        '.icon-box-sm': {
          '@apply w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16': {},
        },
        '.icon-box-md': {
          '@apply w-14 h-14 sm:w-16 sm:h-16 lg:w-20 lg:h-20': {},
        },
        
        // Badge styles
        '.badge-base': {
          '@apply inline-block px-4 sm:px-5 py-1.5 rounded-full text-sm sm:text-base lg:text-lg font-semibold': {},
        },
        '.badge-primary': {
          '@apply bg-blue-500/10 border border-blue-500/20 text-blue-400': {},
        },
        
        // Grid layouts
        '.grid-cards': {
          '@apply grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8': {},
        },
        '.grid-cards-2': {
          '@apply grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-10 lg:gap-12': {},
        },
        
        // Gradient text
        '.gradient-primary': {
          '@apply text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400': {},
        },
        
        // Button base
        '.btn-base': {
          '@apply px-4 py-2 sm:px-6 sm:py-3 rounded-lg font-medium transition-all': {},
        },
        
        // Input base
        '.input-base': {
          '@apply w-full px-4 py-2.5 sm:py-3 text-sm sm:text-base rounded-lg bg-background/50 border border-border focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-all': {},
        },
        
        // Mobile menu overlay
        '.mobile-menu-overlay': {
          '@apply fixed inset-0 bg-slate-950/95 backdrop-blur-xl z-40': {},
        },
        
        // Glow effects
        '.glow-sm': {
          boxShadow: '0 0 20px rgba(99, 102, 241, 0.3)',
        },
        '.glow-md': {
          boxShadow: '0 0 40px rgba(99, 102, 241, 0.4)',
        },
      })
    })
  ],
} satisfies Config;